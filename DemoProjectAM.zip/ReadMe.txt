Alexi Most AIE Programming 2020
Math For Games Assessment

No errors in .exe indicates passing of all unit tests.
Demo Project showcases heirarchical rotation and scaling using matrices.